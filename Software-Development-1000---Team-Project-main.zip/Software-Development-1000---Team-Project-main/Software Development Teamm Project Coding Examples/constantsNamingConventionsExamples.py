# Christian Espinoza 
# 09/22/2024

# Constants Naming Conventions Python example. 

# Constants are variables that don't ever change value

CONSTANT_EXAMPLE = 0 # This is an example of a variable constant.

# Constants are usually capitalized in the format shown but may vary.

# They are completely capitalized to help distinguish them from other variables.

