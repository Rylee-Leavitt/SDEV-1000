# Christian Celis
# 09/20/2024
# SDEV 1000 NT
# Example for Variable Naming Schemes 
# Code is done in python language.


# This program is an example of Naming Conventions for the Coding Standards.


vExample = 0
# This variable displays an example of Camel Casing, which shows the variable written with
#each word being used being capatilized at the start to read the name.

variable_example = 0

# This variables displays an example of Snake Casing, which uses the underscore
#to represent different words.